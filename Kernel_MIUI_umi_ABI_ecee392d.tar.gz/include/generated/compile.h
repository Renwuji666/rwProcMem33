/* This file is auto generated, version 1 */
/* SMP PREEMPT */
#define UTS_MACHINE "aarch64"
#define UTS_VERSION "#1 SMP PREEMPT Thu Jan 1 21:37:36 UTC 2026"
#define LINUX_COMPILE_BY "runner"
#define LINUX_COMPILE_HOST "runnervmdwttx"
#define LINUX_COMPILER "Proton clang version 13.0.0 (https://github.com/llvm/llvm-project b4fd512c36ca344a3ff69350219e8b0a67e9472a), GNU ld (GNU Binutils) 2.36.1"
